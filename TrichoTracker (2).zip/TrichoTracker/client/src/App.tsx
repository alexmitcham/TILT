import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { BottomNav } from "@/components/BottomNav";
import HomePage from "@/pages/HomePage";
import CalendarView from "@/pages/CalendarView";
import BasicCheckIn from "@/pages/BasicCheckIn";
import ResourcesPage from "@/pages/ResourcesPage";
import ProfilePage from "@/pages/ProfilePage";
import CommunityPage from "@/pages/CommunityPage";
import StatsPage from "@/pages/StatsPage";
import TestPage from "@/pages/TestPage";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";

function App() {
  const [location, setLocation] = useLocation();
  
  // Check if we should show the bottom navigation
  const showBottomNav = !["/check-in", "/not-found", "/test"].some(path => 
    location.startsWith(path)
  );

  // Handle empty location
  useEffect(() => {
    if (location === "/") {
      // No need for navigate, just set the location
      setLocation("/home"); // Keep redirecting to home landing page initially
    }
  }, [location, setLocation]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen font-sans bg-background text-foreground">
        <main className="container mx-auto px-4 py-8 pb-20 max-w-md">
          <Switch>
            <Route path="/home" component={HomePage} />
            <Route path="/tracker" component={CalendarView} />
            <Route path="/resources" component={ResourcesPage} />
            <Route path="/profile" component={ProfilePage} />
            <Route path="/community" component={CommunityPage} />
            <Route path="/stats" component={StatsPage} />
            <Route path="/check-in/:date?" component={BasicCheckIn} />
            <Route path="/test" component={TestPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
        {showBottomNav && <BottomNav />}
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
