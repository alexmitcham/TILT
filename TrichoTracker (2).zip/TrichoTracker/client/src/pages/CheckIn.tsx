import { useState, useEffect, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { MoodSlider } from "@/components/ui/mood-slider";
import { HomeLogo } from "@/components/HomeLogo";
import { useEntries } from "@/hooks/useEntries";
import { EntryStatus, PulledStatus } from "@/types";
import { cn, formatDisplayDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function CheckIn() {
  const { date: dateParam } = useParams<{ date?: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { getEntry, saveEntry } = useEntries();

  // Parse date from URL or use today
  const selectedDate = dateParam ? new Date(dateParam) : new Date();

  // Form state
  const [mood, setMood] = useState<number>(5);
  const [urge, setUrge] = useState<EntryStatus>("none");
  const [pulled, setPulled] = useState<PulledStatus>("no");
  const [notes, setNotes] = useState<string>("");

  // Load existing entry data
  useEffect(() => {
    const entry = getEntry(selectedDate);
    if (entry) {
      setMood(entry.mood);
      setUrge(entry.urge);
      setPulled(entry.pulled);
      setNotes(entry.notes || "");
    } else {
      // Reset form for new entries
      setMood(5);
      setUrge("none");
      setPulled("no");
      setNotes("");
    }
  }, [selectedDate, getEntry]);

  // Handle mood change
  const handleMoodChange = useCallback((value: number) => {
    setMood(value);
  }, []);

  // Handle urge selection
  const handleUrgeSelect = useCallback((value: EntryStatus) => {
    setUrge(value);
  }, []);

  // Handle pulled selection
  const handlePulledSelect = useCallback((value: PulledStatus) => {
    setPulled(value);
  }, []);

  // Handle notes change
  const handleNotesChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
  }, []);

  // Handle form submission
  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    saveEntry(selectedDate, {
      mood,
      urge,
      pulled,
      notes
    });
    
    toast({
      title: "Entry saved",
      description: "Your check-in has been recorded."
    });
    
    navigate("/tracker");
  }, [mood, urge, pulled, notes, saveEntry, selectedDate, toast, navigate]);

  // Handle cancel button
  const handleCancel = useCallback(() => {
    navigate("/tracker");
  }, [navigate]);

  return (
    <div className="py-8">
      <div className="bg-secondary rounded-xl p-6 shadow-md">
        <div className="text-center mb-6">
          <HomeLogo className="mb-1" />
          <p className="text-xl text-primary mb-2">Daily Check-In</p>
          <p className="text-sm text-gray-600 mb-4">
            {formatDisplayDate(selectedDate)}
          </p>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          {/* Mood Slider */}
          <div className="space-y-2">
            <label htmlFor="mood" className="block text-primary text-lg font-medium">
              Mood
            </label>
            <MoodSlider 
              value={mood} 
              onChange={handleMoodChange}
            />
          </div>
          
          {/* Urge Intensity */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Urge
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: "none" as EntryStatus, label: "None" },
                { value: "mild" as EntryStatus, label: "Mild" },
                { value: "strong" as EntryStatus, label: "Strong" }
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handleUrgeSelect(option.value)}
                  className={cn(
                    "py-2 px-4 rounded-lg transition-colors border-2",
                    urge === option.value
                      ? "bg-primary text-white border-primary" 
                      : "bg-white/50 hover:bg-white/70 border-transparent"
                  )}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* Pulled Hair */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Pulled hair?
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "no" as PulledStatus, label: "No" },
                { value: "yes" as PulledStatus, label: "Yes" }
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handlePulledSelect(option.value)}
                  className={cn(
                    "py-2 px-4 rounded-lg transition-colors border-2",
                    pulled === option.value
                      ? "bg-primary text-white border-primary" 
                      : "bg-white/50 hover:bg-white/70 border-transparent"
                  )}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* Notes */}
          <div className="space-y-2">
            <label htmlFor="notes" className="block text-primary text-lg font-medium">
              Notes (optional)
            </label>
            <textarea
              id="notes"
              name="notes"
              placeholder="Enter any additional notes here..."
              className="w-full h-24 p-3 bg-white/50 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              value={notes}
              onChange={handleNotesChange}
            />
          </div>
          
          {/* Save Button */}
          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-8 rounded-lg text-lg transition shadow-md"
          >
            Save
          </Button>
          
          {/* Cancel Button */}
          <Button
            type="button"
            variant="outline"
            className="w-full bg-transparent border border-primary text-primary font-bold py-3 px-8 rounded-lg text-lg transition"
            onClick={handleCancel}
          >
            Cancel
          </Button>
        </form>
      </div>
    </div>
  );
}
