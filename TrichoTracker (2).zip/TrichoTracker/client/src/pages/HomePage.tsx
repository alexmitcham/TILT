import { useCallback } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { HomeLogo } from "@/components/HomeLogo";
import { IllustrationSVG } from "@/components/IllustrationSVG";

export default function HomePage() {
  const [, navigate] = useLocation();

  const handleGetStarted = useCallback(() => {
    navigate("/tracker");
  }, [navigate]);

  return (
    <div className="flex flex-col items-center justify-center text-center min-h-[80vh]">
      <HomeLogo className="mb-6" />
      
      <h1 className="text-4xl font-bold text-primary mb-4">
        Support for Trichotillomania
      </h1>
      
      <p className="mb-4 text-lg">
        Tilt the balance with tools, resources, and a caring community.
      </p>
      
      <p className="mb-8 text-sm text-gray-600">
        Track your journey, identify triggers, and visualize your progress with detailed statistics
      </p>
      
      <div className="flex justify-center mb-8 relative w-56 h-56">
        <IllustrationSVG />
      </div>
      
      <Button 
        className="bg-primary hover:bg-primary/90 text-white font-bold py-3 px-8 rounded-full text-lg transition shadow-md"
        onClick={handleGetStarted}
      >
        Get Started
      </Button>
    </div>
  );
}
