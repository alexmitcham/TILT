import { useState, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CalendarDot, CalendarLegend } from "@/components/ui/calendar-dots";
import { HomeLogo } from "@/components/HomeLogo";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn, formatDateString, formatMonthYear, generateCalendarDays } from "@/lib/utils";
import { useEntries } from "@/hooks/useEntries";
import { DayInfo } from "@/types";

// Import the same storage key used in useEntries to ensure consistency
const STORAGE_KEY = "tiltAppData";

export default function CalendarView() {
  const [, navigate] = useLocation();
  const { entries } = useEntries();
  const [currentDate, setCurrentDate] = useState(new Date());
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();
  
  // Force a refresh of entries from localStorage when the component mounts or remounts
  useEffect(() => {
    // This will trigger a reload of entries from localStorage
    const storedData = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{"entries":{}}');
    console.log("CalendarView - Fresh entries from localStorage:", storedData.entries);
  }, []);

  const calendarDays = generateCalendarDays(currentYear, currentMonth);

  const goToPreviousMonth = useCallback(() => {
    setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
  }, [currentYear, currentMonth]);

  const goToNextMonth = useCallback(() => {
    setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
  }, [currentYear, currentMonth]);

  const handleDayClick = useCallback(
    (dayInfo: DayInfo | null) => {
      if (!dayInfo) return;
      navigate(`/check-in/${dayInfo.dateString}`);
    },
    [navigate]
  );

  const handleLogEntry = useCallback(() => {
    const today = formatDateString(new Date());
    navigate(`/check-in/${today}`);
  }, [navigate]);

  return (
    <div className="py-8">
      <div className="bg-secondary rounded-xl p-6 shadow-md">
        <div className="text-center mb-6">
          <HomeLogo className="mb-4" />
          
          {/* Month Selector */}
          <div className="bg-white/50 rounded-xl p-4 mb-4">
            <h3 className="text-primary text-xl mb-2">
              {formatMonthYear(currentDate)}
            </h3>
            
            <div className="flex justify-between items-center">
              <button 
                className="text-primary"
                onClick={goToPreviousMonth}
                aria-label="Previous month"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              
              <div className="grid grid-cols-7 gap-1 w-full max-w-xs mx-auto">
                {/* Day headers */}
                {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => (
                  <div key={index} className="text-center text-sm font-medium">
                    {day}
                  </div>
                ))}
                
                {/* Calendar days */}
                {calendarDays.map((day, index) => {
                  if (day === null) {
                    return <CalendarDot key={index} isEmptySlot={true} />;
                  }
                  
                  const entry = entries[day.dateString];
                  
                  return (
                    <CalendarDot
                      key={index}
                      date={day.dateString}
                      entry={entry}
                      dayNumber={day.dayNumber}
                      onClick={() => handleDayClick(day)}
                    />
                  );
                })}
              </div>
              
              <button 
                className="text-primary"
                onClick={goToNextMonth}
                aria-label="Next month"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </div>
          </div>
          
          <div className="flex flex-col space-y-3">
            <Button
              className={cn(
                "bg-primary hover:bg-primary/90 text-white",
                "font-bold py-3 px-8 rounded-full text-lg transition shadow-md"
              )}
              onClick={handleLogEntry}
            >
              Log Entry
            </Button>
            
            <Button
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
              onClick={() => navigate("/stats")}
            >
              View Stats & Trends
            </Button>
          </div>
        </div>
        
        <CalendarLegend />
      </div>
    </div>
  );
}
