import { useState, useCallback, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { HomeLogo } from "@/components/HomeLogo";
import { useEntries } from "@/hooks/useEntries";
import { EntryStatus, PulledStatus } from "@/types";
import { formatDateString, formatDisplayDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// Import the same storage key used in useEntries to ensure consistency
const STORAGE_KEY = "tiltAppData";

export default function BasicCheckIn() {
  const { date: dateParam } = useParams<{ date?: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { saveEntry, getEntry } = useEntries();

  // Parse date from URL or use today
  const selectedDate = dateParam ? new Date(dateParam) : new Date();
  
  // Form state with simple useState
  const [mood, setMood] = useState(5);
  const [urge, setUrge] = useState<EntryStatus>("none");
  const [pulled, setPulled] = useState<PulledStatus>("no");
  const [notes, setNotes] = useState("");
  
  // Load existing entry when component mounts or date changes
  useEffect(() => {
    console.log("BasicCheckIn - Loading entry for date:", selectedDate);
    
    // Get directly from localStorage for reliability
    try {
      const savedData = localStorage.getItem(STORAGE_KEY);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        // Format date consistently with how we save it using our utility
        const dateString = formatDateString(selectedDate);
        console.log("Looking for entry with dateString:", dateString);
        console.log("Available entries:", parsedData.entries);
        
        if (parsedData.entries && parsedData.entries[dateString]) {
          const entry = parsedData.entries[dateString];
          console.log("Found existing entry:", entry);
          
          // Set form values from saved entry
          setMood(entry.mood || 5);
          setUrge(entry.urge || "none");
          setPulled(entry.pulled || "no");
          setNotes(entry.notes || "");
        } else {
          console.log("No existing entry for this date");
        }
      }
    } catch (error) {
      console.error("Error loading entry:", error);
    }
  }, [selectedDate]);
  
  // Basic handlers without useCallback for simplicity
  const handleMood1 = () => setMood(1);
  const handleMood2 = () => setMood(2);
  const handleMood3 = () => setMood(3);
  const handleMood4 = () => setMood(4);
  const handleMood5 = () => setMood(5);
  const handleMood6 = () => setMood(6);
  const handleMood7 = () => setMood(7);
  const handleMood8 = () => setMood(8);
  const handleMood9 = () => setMood(9);
  const handleMood10 = () => setMood(10);
  
  const handleUrgeNone = () => setUrge("none");
  const handleUrgeMild = () => setUrge("mild");
  const handleUrgeStrong = () => setUrge("strong");
  
  const handlePulledNo = () => setPulled("no");
  const handlePulledYes = () => setPulled("yes");
  
  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
  };
  
  const handleSave = useCallback(() => {
    console.log("Saving entry for date:", selectedDate);
    console.log("Entry data:", { mood, urge, pulled, notes });
    
    saveEntry(selectedDate, {
      mood,
      urge,
      pulled,
      notes
    });
    
    console.log("Entry saved, navigating to tracker");
    
    toast({
      title: "Entry saved",
      description: "Your check-in has been recorded."
    });
    
    navigate("/tracker");
  }, [mood, urge, pulled, notes, saveEntry, selectedDate, toast, navigate]);
  
  const handleCancel = useCallback(() => {
    navigate("/tracker");
  }, [navigate]);

  return (
    <div className="py-8">
      <div className="bg-secondary rounded-xl p-6 shadow-md">
        <div className="text-center mb-6">
          <HomeLogo className="mb-1" />
          <p className="text-xl text-primary mb-2">Daily Check-In</p>
          <p className="text-sm text-gray-600 mb-4">
            {formatDisplayDate(selectedDate)}
          </p>
        </div>
        
        {/* Simplified form with plain divs instead of a form */}
        <div className="space-y-6">
          {/* Mood Selection */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Mood (Current: {mood})
            </label>
            <div className="grid grid-cols-5 gap-2">
              <button onClick={handleMood1} className={`p-2 rounded ${mood === 1 ? 'bg-primary text-white' : 'bg-white'}`}>1</button>
              <button onClick={handleMood2} className={`p-2 rounded ${mood === 2 ? 'bg-primary text-white' : 'bg-white'}`}>2</button>
              <button onClick={handleMood3} className={`p-2 rounded ${mood === 3 ? 'bg-primary text-white' : 'bg-white'}`}>3</button>
              <button onClick={handleMood4} className={`p-2 rounded ${mood === 4 ? 'bg-primary text-white' : 'bg-white'}`}>4</button>
              <button onClick={handleMood5} className={`p-2 rounded ${mood === 5 ? 'bg-primary text-white' : 'bg-white'}`}>5</button>
              <button onClick={handleMood6} className={`p-2 rounded ${mood === 6 ? 'bg-primary text-white' : 'bg-white'}`}>6</button>
              <button onClick={handleMood7} className={`p-2 rounded ${mood === 7 ? 'bg-primary text-white' : 'bg-white'}`}>7</button>
              <button onClick={handleMood8} className={`p-2 rounded ${mood === 8 ? 'bg-primary text-white' : 'bg-white'}`}>8</button>
              <button onClick={handleMood9} className={`p-2 rounded ${mood === 9 ? 'bg-primary text-white' : 'bg-white'}`}>9</button>
              <button onClick={handleMood10} className={`p-2 rounded ${mood === 10 ? 'bg-primary text-white' : 'bg-white'}`}>10</button>
            </div>
          </div>
          
          {/* Urge Selection */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Urge (Current: {urge})
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleUrgeNone}
                className={`p-2 rounded-lg ${urge === "none" ? 'bg-primary text-white' : 'bg-white'}`}
              >
                None
              </button>
              <button
                onClick={handleUrgeMild}
                className={`p-2 rounded-lg ${urge === "mild" ? 'bg-primary text-white' : 'bg-white'}`}
              >
                Mild
              </button>
              <button
                onClick={handleUrgeStrong}
                className={`p-2 rounded-lg ${urge === "strong" ? 'bg-primary text-white' : 'bg-white'}`}
              >
                Strong
              </button>
            </div>
          </div>
          
          {/* Pulled Hair */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Pulled hair? (Current: {pulled})
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handlePulledNo}
                className={`p-2 rounded-lg ${pulled === "no" ? 'bg-primary text-white' : 'bg-white'}`}
              >
                No
              </button>
              <button
                onClick={handlePulledYes}
                className={`p-2 rounded-lg ${pulled === "yes" ? 'bg-primary text-white' : 'bg-white'}`}
              >
                Yes
              </button>
            </div>
          </div>
          
          {/* Triggers */}
          <div className="space-y-2">
            <label htmlFor="notes" className="block text-primary text-lg font-medium">
              Triggers & Notes
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={handleNotesChange}
              className="w-full h-24 p-3 bg-white rounded-lg resize-none border border-gray-300"
              placeholder="What triggered you today? Were you stressed, anxious, bored? Describe your environment and feelings..."
            ></textarea>
            <p className="text-xs text-gray-500">
              Adding details about triggers helps identify patterns in the Stats page.
            </p>
          </div>
          
          {/* Save Button */}
          <button
            onClick={handleSave}
            className="w-full bg-primary text-white font-bold py-3 rounded-lg text-lg"
          >
            Save
          </button>
          
          {/* Cancel Button */}
          <button
            onClick={handleCancel}
            className="w-full bg-white text-primary font-bold py-3 rounded-lg text-lg border border-primary"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}