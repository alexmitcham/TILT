import { useState, useEffect } from "react";
import { HomeLogo } from "@/components/HomeLogo";
import { BottomNav } from "@/components/BottomNav";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

// Post interface for type safety
interface Post {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  likes: number;
  comments: Comment[];
  isLiked?: boolean;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
}

// Storage key for community posts
const COMMUNITY_STORAGE_KEY = "tiltCommunityPosts";
const PROFILE_STORAGE_KEY = "tiltProfile";

export default function CommunityPage() {
  const { toast } = useToast();
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPost, setNewPost] = useState("");
  const [profileName, setProfileName] = useState("Guest User");
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [newComment, setNewComment] = useState("");
  
  // Sample posts to show on first load
  const samplePosts: Post[] = [
    {
      id: "1",
      author: "TILT Team",
      content: "Welcome to the TILT community! This is a safe space to share your experiences, successes, and challenges with trichotillomania. We're all in this together. 💪",
      timestamp: new Date().toISOString(),
      likes: 5,
      comments: [
        {
          id: "c1",
          author: "TILT Support",
          content: "Remember to be kind and supportive to one another!",
          timestamp: new Date().toISOString()
        }
      ]
    },
    {
      id: "2",
      author: "TILT Team",
      content: "Tip of the day: Fidget toys can help keep your hands busy during high-stress moments when urges may be stronger.",
      timestamp: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
      likes: 3,
      comments: []
    }
  ];
  
  // Load posts and profile name on initial render
  useEffect(() => {
    // Load profile for author name
    try {
      const savedProfile = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (savedProfile) {
        const profile = JSON.parse(savedProfile);
        setProfileName(profile.name);
      }
    } catch (error) {
      console.error("Error loading profile:", error);
    }
    
    // Load community posts
    try {
      const savedPosts = localStorage.getItem(COMMUNITY_STORAGE_KEY);
      if (savedPosts) {
        setPosts(JSON.parse(savedPosts));
        console.log("Community posts loaded:", JSON.parse(savedPosts));
      } else {
        // If no posts exist, use the sample posts
        localStorage.setItem(COMMUNITY_STORAGE_KEY, JSON.stringify(samplePosts));
        setPosts(samplePosts);
        console.log("Sample posts loaded");
      }
    } catch (error) {
      console.error("Error loading community posts:", error);
    }
  }, []);
  
  // Save posts to local storage
  const savePosts = (updatedPosts: Post[]) => {
    try {
      localStorage.setItem(COMMUNITY_STORAGE_KEY, JSON.stringify(updatedPosts));
      console.log("Posts saved:", updatedPosts);
    } catch (error) {
      console.error("Error saving posts:", error);
      toast({
        title: "Error saving",
        description: "There was a problem saving to local storage.",
        variant: "destructive"
      });
    }
  };
  
  // Handle creating a new post
  const handleCreatePost = () => {
    if (!newPost.trim()) {
      toast({
        title: "Empty post",
        description: "Please write something before posting.",
        variant: "destructive"
      });
      return;
    }
    
    const post: Post = {
      id: Date.now().toString(),
      author: profileName,
      content: newPost,
      timestamp: new Date().toISOString(),
      likes: 0,
      comments: []
    };
    
    const updatedPosts = [post, ...posts];
    setPosts(updatedPosts);
    savePosts(updatedPosts);
    setNewPost("");
    
    toast({
      title: "Post shared",
      description: "Your post has been shared with the community."
    });
  };
  
  // Handle liking a post
  const handleLike = (postId: string) => {
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        // Toggle like status
        const isLiked = post.isLiked || false;
        const likeDelta = isLiked ? -1 : 1;
        return {
          ...post,
          likes: post.likes + likeDelta,
          isLiked: !isLiked
        };
      }
      return post;
    });
    
    setPosts(updatedPosts);
    savePosts(updatedPosts);
  };
  
  // Handle adding a comment
  const handleAddComment = () => {
    if (!selectedPostId || !newComment.trim()) {
      toast({
        title: "Empty comment",
        description: "Please write something before commenting.",
        variant: "destructive"
      });
      return;
    }
    
    const comment: Comment = {
      id: Date.now().toString(),
      author: profileName,
      content: newComment,
      timestamp: new Date().toISOString()
    };
    
    const updatedPosts = posts.map(post => {
      if (post.id === selectedPostId) {
        return {
          ...post,
          comments: [...post.comments, comment]
        };
      }
      return post;
    });
    
    setPosts(updatedPosts);
    savePosts(updatedPosts);
    setNewComment("");
    
    toast({
      title: "Comment added",
      description: "Your comment has been added to the post."
    });
  };
  
  // Format timestamp to a readable format
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.round(diffMs / 60000);
    const diffHrs = Math.round(diffMs / 3600000);
    const diffDays = Math.round(diffMs / 86400000);
    
    if (diffMins < 60) {
      return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHrs < 24) {
      return `${diffHrs} hour${diffHrs !== 1 ? 's' : ''} ago`;
    } else {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    }
  };
  
  return (
    <div className="container mx-auto max-w-md px-4 pb-20">
      <div className="text-center my-6">
        <HomeLogo className="mb-2" />
        <h1 className="text-2xl font-bold text-primary">Community</h1>
        <p className="text-sm text-gray-600">
          Share your journey, ask questions, and support others
        </p>
      </div>
      
      {/* New Post Creation */}
      <div className="bg-secondary rounded-xl p-4 shadow-md mb-6">
        <h2 className="text-lg font-bold text-primary mb-2">Share with the community</h2>
        <Textarea
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
          placeholder="What's on your mind today?"
          className="w-full h-24 mb-3"
        />
        <Button 
          onClick={handleCreatePost}
          className="w-full bg-primary"
        >
          Post
        </Button>
      </div>
      
      {/* Posts List */}
      <div className="space-y-4">
        {posts.map(post => (
          <div key={post.id} className="bg-secondary rounded-xl p-4 shadow-md">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-bold">{post.author}</h3>
                <p className="text-xs text-gray-500">{formatTimestamp(post.timestamp)}</p>
              </div>
            </div>
            
            <p className="mb-3 whitespace-pre-wrap">{post.content}</p>
            
            <div className="flex items-center justify-between mb-2">
              <button 
                onClick={() => handleLike(post.id)}
                className={`flex items-center ${post.isLiked ? 'text-pink-500' : 'text-gray-500'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill={post.isLiked ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                {post.likes} like{post.likes !== 1 ? 's' : ''}
              </button>
              
              <button 
                onClick={() => setSelectedPostId(selectedPostId === post.id ? null : post.id)}
                className="text-gray-500 text-sm"
              >
                {post.comments.length} comment{post.comments.length !== 1 ? 's' : ''}
              </button>
            </div>
            
            {/* Comments Section */}
            {selectedPostId === post.id && (
              <div className="mt-3">
                <div className="bg-white rounded-lg p-3 mb-2">
                  {post.comments.length > 0 ? (
                    <div className="space-y-2">
                      {post.comments.map(comment => (
                        <div key={comment.id} className="border-b border-gray-100 pb-2 last:border-0 last:pb-0">
                          <div className="flex justify-between items-start">
                            <span className="font-medium">{comment.author}</span>
                            <span className="text-xs text-gray-500">{formatTimestamp(comment.timestamp)}</span>
                          </div>
                          <p className="text-sm">{comment.content}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 text-center">No comments yet</p>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    className="flex-1 h-10 min-h-0 py-2"
                  />
                  <Button 
                    onClick={handleAddComment}
                    className="bg-primary px-3"
                  >
                    Send
                  </Button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      
      <BottomNav />
    </div>
  );
}