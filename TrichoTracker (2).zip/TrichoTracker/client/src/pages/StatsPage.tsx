import { useState, useEffect, useMemo } from "react";
import { HomeLogo } from "@/components/HomeLogo";
import { useEntries } from "@/hooks/useEntries";
import { Entry } from "@/types";
import { formatDisplayDate } from "@/lib/utils";
import { AreaChart, Area, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";

// Tab type for navigation
type StatTab = "weekly" | "monthly" | "triggers";

// Colors for charts
const COLORS = {
  mood: "#F87171",   // red-400
  urge: "#FBBF24",   // amber-400
  pulled: "#EF4444", // red-500
  noPull: "#10B981", // emerald-500
  mild: "#FBBF24",   // amber-400
  strong: "#F97316", // orange-500
};

export default function StatsPage() {
  const { entries } = useEntries();
  const [activeTab, setActiveTab] = useState<StatTab>("weekly");
  const [weekOffset, setWeekOffset] = useState(0);
  const [monthOffset, setMonthOffset] = useState(0);

  // Get all entries as an array
  const entriesArray = useMemo(() => {
    return Object.values(entries).sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  }, [entries]);

  // Generate weekly data
  const weeklyData = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay() + (weekOffset * 7)); // Sunday
    
    const weekDates = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      return date;
    });
    
    return weekDates.map(date => {
      const dateStr = date.toISOString().split('T')[0];
      const entry = entries[dateStr];
      const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
      
      return {
        name: dayName,
        date: dateStr,
        mood: entry?.mood || 0,
        urge: entry?.urge === "strong" ? 3 : (entry?.urge === "mild" ? 2 : 1),
        pulled: entry?.pulled === "yes" ? 1 : 0,
        hasEntry: !!entry
      };
    });
  }, [entries, weekOffset]);

  // Generate monthly data
  const monthlyData = useMemo(() => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + monthOffset;
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const totalDays = lastDay.getDate();
    const monthName = firstDay.toLocaleDateString('en-US', { month: 'long' });
    
    const counts = {
      totalEntries: 0,
      pulledDays: 0,
      noPullDays: 0,
      mildUrgeDays: 0,
      strongUrgeDays: 0,
      avgMood: 0
    };
    
    // Collect data for the month
    for (let day = 1; day <= totalDays; day++) {
      const date = new Date(year, month, day);
      const dateStr = date.toISOString().split('T')[0];
      const entry = entries[dateStr];
      
      if (entry) {
        counts.totalEntries++;
        if (entry.pulled === "yes") counts.pulledDays++;
        else counts.noPullDays++;
        
        if (entry.urge === "mild") counts.mildUrgeDays++;
        if (entry.urge === "strong") counts.strongUrgeDays++;
        
        counts.avgMood += entry.mood || 0;
      }
    }
    
    // Calculate average mood
    counts.avgMood = counts.totalEntries > 0 
      ? Math.round((counts.avgMood / counts.totalEntries) * 10) / 10
      : 0;
    
    // Create data for pie chart
    const pieData = [
      { name: "No Pulling", value: counts.noPullDays, color: COLORS.noPull },
      { name: "Pulled", value: counts.pulledDays, color: COLORS.pulled }
    ];
    
    const urgeData = [
      { name: "No Urge", value: counts.totalEntries - counts.mildUrgeDays - counts.strongUrgeDays, color: COLORS.noPull },
      { name: "Mild Urge", value: counts.mildUrgeDays, color: COLORS.mild },
      { name: "Strong Urge", value: counts.strongUrgeDays, color: COLORS.strong }
    ];
    
    return {
      monthName,
      counts,
      pieData,
      urgeData
    };
  }, [entries, monthOffset]);

  // Analyze common triggers
  const triggerAnalysis = useMemo(() => {
    const triggers: Record<string, number> = {};
    const keywords = [
      "stress", "anxiety", "tired", "bored", "focused", 
      "studying", "watching", "reading", "work", "school",
      "nervous", "exam", "meeting", "interview", "presentation",
      "frustrated", "angry", "sad", "depressed", "lonely"
    ];
    
    // Count occurrences of trigger words in notes
    Object.values(entries).forEach(entry => {
      if (entry.notes) {
        const lowerNotes = entry.notes.toLowerCase();
        keywords.forEach(keyword => {
          if (lowerNotes.includes(keyword)) {
            triggers[keyword] = (triggers[keyword] || 0) + 1;
          }
        });
      }
    });
    
    // Sort by occurrence count
    const sortedTriggers = Object.entries(triggers)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5) // Get top 5
      .map(([name, value]) => ({ name, value }));
    
    return sortedTriggers;
  }, [entries]);

  // Format data for trigger correlation
  const triggerCorrelation = useMemo(() => {
    const pulledByTrigger: Record<string, { total: number, pulled: number }> = {};
    const keywords = [
      "stress", "anxiety", "tired", "bored", "focused", 
      "studying", "watching", "reading", "work", "school"
    ];
    
    // Analyze correlation between triggers and pulling
    Object.values(entries).forEach(entry => {
      if (entry.notes) {
        const lowerNotes = entry.notes.toLowerCase();
        keywords.forEach(keyword => {
          if (lowerNotes.includes(keyword)) {
            if (!pulledByTrigger[keyword]) {
              pulledByTrigger[keyword] = { total: 0, pulled: 0 };
            }
            
            pulledByTrigger[keyword].total += 1;
            if (entry.pulled === "yes") {
              pulledByTrigger[keyword].pulled += 1;
            }
          }
        });
      }
    });
    
    // Calculate pull percentage and sort
    return Object.entries(pulledByTrigger)
      .filter(([, data]) => data.total >= 2) // Only include triggers with at least 2 occurrences
      .map(([name, data]) => ({
        name,
        pullRate: Math.round((data.pulled / data.total) * 100),
        occurrences: data.total
      }))
      .sort((a, b) => b.pullRate - a.pullRate)
      .slice(0, 5); // Top 5
  }, [entries]);

  // Navigation between tabs
  const handleTabChange = (tab: StatTab) => {
    setActiveTab(tab);
  };

  // Navigation for weekly stats
  const goToPreviousWeek = () => {
    setWeekOffset(weekOffset - 1);
  };
  
  const goToNextWeek = () => {
    setWeekOffset(weekOffset + 1);
  };
  
  // Navigation for monthly stats
  const goToPreviousMonth = () => {
    setMonthOffset(monthOffset - 1);
  };
  
  const goToNextMonth = () => {
    setMonthOffset(monthOffset + 1);
  };

  // Get week date range string
  const getWeekRangeText = () => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay() + (weekOffset * 7));
    
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    
    return `${formatDisplayDate(startOfWeek)} - ${formatDisplayDate(endOfWeek)}`;
  };

  return (
    <div className="py-6 mb-16">
      <div className="bg-secondary rounded-xl p-4 shadow-md">
        <div className="text-center mb-4">
          <HomeLogo className="mb-2" />
          <h1 className="text-2xl font-bold text-primary">Stats & Trends</h1>
          <p className="text-sm text-gray-600 mb-4">
            Track your progress and identify patterns
          </p>
        </div>
        
        {/* Tab Navigation */}
        <div className="flex mb-4 bg-white rounded-lg p-1">
          <button
            className={`flex-1 py-2 px-4 rounded-lg ${activeTab === "weekly" ? "bg-primary text-white" : ""}`}
            onClick={() => handleTabChange("weekly")}
          >
            Weekly
          </button>
          <button
            className={`flex-1 py-2 px-4 rounded-lg ${activeTab === "monthly" ? "bg-primary text-white" : ""}`}
            onClick={() => handleTabChange("monthly")}
          >
            Monthly
          </button>
          <button
            className={`flex-1 py-2 px-4 rounded-lg ${activeTab === "triggers" ? "bg-primary text-white" : ""}`}
            onClick={() => handleTabChange("triggers")}
          >
            Triggers
          </button>
        </div>
        
        {/* Weekly Stats */}
        {activeTab === "weekly" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <button 
                className="bg-white rounded-full p-2 shadow-sm"
                onClick={goToPreviousWeek}
              >
                ←
              </button>
              <h2 className="text-lg font-medium">{getWeekRangeText()}</h2>
              <button 
                className="bg-white rounded-full p-2 shadow-sm"
                onClick={goToNextWeek}
              >
                →
              </button>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <h3 className="text-primary font-medium mb-2">Mood & Urges</h3>
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={weeklyData}
                    margin={{ top: 5, right: 5, bottom: 5, left: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" domain={[0, 10]} />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 3]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      yAxisId="left"
                      type="monotone" 
                      dataKey="mood" 
                      stroke={COLORS.mood} 
                      name="Mood" 
                      connectNulls
                      dot={{ r: 4 }}
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      yAxisId="right"
                      type="monotone" 
                      dataKey="urge" 
                      stroke={COLORS.urge} 
                      name="Urge Level" 
                      connectNulls
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <h3 className="text-primary font-medium mb-2">Pulling Episodes</h3>
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={weeklyData}
                    margin={{ top: 5, right: 5, bottom: 5, left: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 1]} ticks={[0, 1]} />
                    <Tooltip />
                    <Legend />
                    <Bar 
                      dataKey="pulled" 
                      fill={COLORS.pulled}
                      name="Hair Pulled" 
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
        
        {/* Monthly Stats */}
        {activeTab === "monthly" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <button 
                className="bg-white rounded-full p-2 shadow-sm"
                onClick={goToPreviousMonth}
              >
                ←
              </button>
              <h2 className="text-lg font-medium">{monthlyData.monthName}</h2>
              <button 
                className="bg-white rounded-full p-2 shadow-sm"
                onClick={goToNextMonth}
              >
                →
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 flex flex-col items-center">
                <h3 className="text-primary font-medium mb-1">Entries</h3>
                <p className="text-4xl font-bold">{monthlyData.counts.totalEntries}</p>
                <p className="text-sm text-gray-500">days tracked</p>
              </div>
              <div className="bg-white rounded-lg p-4 flex flex-col items-center">
                <h3 className="text-primary font-medium mb-1">Avg Mood</h3>
                <p className="text-4xl font-bold">{monthlyData.counts.avgMood}</p>
                <p className="text-sm text-gray-500">out of 10</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4">
                <h3 className="text-primary font-medium mb-2 text-center">Pulling Status</h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={monthlyData.pieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={60}
                        fill="#8884d8"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {monthlyData.pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-4">
                <h3 className="text-primary font-medium mb-2 text-center">Urge Intensity</h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={monthlyData.urgeData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={60}
                        fill="#8884d8"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {monthlyData.urgeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Triggers Analysis */}
        {activeTab === "triggers" && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg p-4">
              <h3 className="text-primary font-medium mb-2">Common Triggers</h3>
              <p className="text-sm text-gray-600 mb-4">
                Based on analysis of your journal entries
              </p>
              
              {triggerAnalysis.length > 0 ? (
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={triggerAnalysis}
                      layout="vertical"
                      margin={{ top: 5, right: 5, bottom: 5, left: 50 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" />
                      <Tooltip />
                      <Legend />
                      <Bar 
                        dataKey="value" 
                        fill={COLORS.urge}
                        name="Occurrences" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="text-center p-8">
                  <p>Not enough data for trigger analysis.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Add notes to your check-ins to help identify triggers.
                  </p>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <h3 className="text-primary font-medium mb-2">Trigger Correlation</h3>
              <p className="text-sm text-gray-600 mb-4">
                Percentage of times a trigger leads to pulling
              </p>
              
              {triggerCorrelation.length > 0 ? (
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={triggerCorrelation}
                      margin={{ top: 5, right: 5, bottom: 5, left: 50 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" unit="%" domain={[0, 100]} />
                      <YAxis type="category" dataKey="name" />
                      <Tooltip formatter={(value) => [`${value}%`, 'Pull Rate']} />
                      <Legend />
                      <Bar 
                        dataKey="pullRate" 
                        fill={COLORS.pulled}
                        name="Pull Rate" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="text-center p-8">
                  <p>Not enough data for correlation analysis.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Continue tracking to see correlations.
                  </p>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <h3 className="text-primary font-medium mb-2">Tips Based on Your Data</h3>
              
              {triggerCorrelation.length > 0 ? (
                <ul className="list-disc pl-5 space-y-2">
                  {triggerCorrelation.slice(0, 3).map((trigger, index) => (
                    <li key={index}>
                      <span className="font-medium">{trigger.name}</span> is a frequent trigger 
                      (linked to pulling {trigger.pullRate}% of the time). Consider developing 
                      specific strategies for this situation.
                    </li>
                  ))}
                  <li>
                    Track consistently to improve these insights and identify more patterns.
                  </li>
                </ul>
              ) : (
                <div>
                  <p className="mb-2">Add more entries with detailed notes to get personalized tips:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Mention activities you were doing when urges occurred</li>
                    <li>Note your emotional state (stressed, tired, bored, etc.)</li>
                    <li>Record specific locations or times when pulling happens</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}