import { HomeLogo } from "@/components/HomeLogo";

export default function ResourcesPage() {
  return (
    <div className="py-8 mb-16">
      <div className="bg-secondary rounded-xl p-6 shadow-md">
        <div className="text-center mb-6">
          <HomeLogo className="mb-4" />
          <h1 className="text-2xl font-bold text-primary mb-6">Resources</h1>
        </div>
        
        <div className="space-y-6">
          <div className="bg-white/50 rounded-lg p-4">
            <h3 className="text-primary text-lg font-medium mb-2">Support Groups</h3>
            <p className="mb-2">
              Connecting with others who understand what you're going through can be incredibly helpful.
            </p>
            <a 
              href="https://www.trichstop.com/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              TrichStop Community →
            </a>
          </div>
          
          <div className="bg-white/50 rounded-lg p-4">
            <h3 className="text-primary text-lg font-medium mb-2">Coping Strategies</h3>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Fidget toys for your hands</li>
              <li>Stress reduction techniques</li>
              <li>Mindfulness practices</li>
              <li>Habit reversal training</li>
            </ul>
          </div>
          
          <div className="bg-white/50 rounded-lg p-4">
            <h3 className="text-primary text-lg font-medium mb-2">Professional Help</h3>
            <p className="mb-2">
              Consider working with a mental health professional who specializes in trichotillomania or body-focused repetitive behaviors.
            </p>
            <a 
              href="https://www.bfrb.org/find-help" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              Find a Therapist →
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}