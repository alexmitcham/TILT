import { useState, useEffect, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { HomeLogo } from "@/components/HomeLogo";
import { useEntries } from "@/hooks/useEntries";
import { EntryStatus, PulledStatus } from "@/types";
import { formatDisplayDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function SimpleCheckIn() {
  const { date: dateParam } = useParams<{ date?: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { getEntry, saveEntry } = useEntries();

  // Parse date from URL or use today
  const selectedDate = dateParam ? new Date(dateParam) : new Date();

  // Form state
  const [mood, setMood] = useState<number>(5);
  const [urge, setUrge] = useState<EntryStatus>("none");
  const [pulled, setPulled] = useState<PulledStatus>("no");
  const [notes, setNotes] = useState<string>("");

  // Load existing entry data
  useEffect(() => {
    const entry = getEntry(selectedDate);
    if (entry) {
      setMood(entry.mood);
      setUrge(entry.urge);
      setPulled(entry.pulled);
      setNotes(entry.notes || "");
    } else {
      // Reset form for new entries
      setMood(5);
      setUrge("none");
      setPulled("no");
      setNotes("");
    }
  }, [selectedDate, getEntry]);

  // Memoized handlers using useCallback to prevent unnecessary re-renders
  const handleMoodChange = useCallback((value: number) => {
    setMood(value);
  }, []);

  const handleUrgeChange = useCallback((value: EntryStatus) => {
    setUrge(value);
  }, []);

  const handlePulledChange = useCallback((value: PulledStatus) => {
    setPulled(value);
  }, []);

  const handleNotesChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
  }, []);

  // Form submission
  const handleSubmit = useCallback((e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    saveEntry(selectedDate, {
      mood,
      urge,
      pulled,
      notes
    });
    
    toast({
      title: "Entry saved",
      description: "Your check-in has been recorded."
    });
    
    navigate("/tracker");
  }, [mood, urge, pulled, notes, saveEntry, selectedDate, toast, navigate]);

  const handleCancel = useCallback(() => {
    navigate("/tracker");
  }, [navigate]);

  return (
    <div className="py-8">
      <div className="bg-secondary rounded-xl p-6 shadow-md">
        <div className="text-center mb-6">
          <HomeLogo className="mb-1" />
          <p className="text-xl text-primary mb-2">Daily Check-In</p>
          <p className="text-sm text-gray-600 mb-4">
            {formatDisplayDate(selectedDate)}
          </p>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          {/* Mood Selection */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Mood
            </label>
            <div className="grid grid-cols-10 gap-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => handleMoodChange(value)}
                  className={`h-10 rounded-full ${
                    mood === value 
                      ? "bg-primary text-white scale-110 shadow-md" 
                      : "bg-white/50 hover:bg-white/70"
                  }`}
                >
                  {value}
                </button>
              ))}
            </div>
            <div className="flex justify-between text-xs text-gray-500 px-1">
              <span>Low mood</span>
              <span>High mood</span>
            </div>
          </div>
          
          {/* Urge Intensity with simple buttons */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Urge
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: "none" as EntryStatus, label: "None" },
                { value: "mild" as EntryStatus, label: "Mild" },
                { value: "strong" as EntryStatus, label: "Strong" }
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handleUrgeChange(option.value)}
                  className={`py-2 px-4 rounded-lg transition-colors ${
                    urge === option.value 
                      ? "bg-primary text-white" 
                      : "bg-white/50 hover:bg-white/70"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* Pulled Hair */}
          <div className="space-y-2">
            <label className="block text-primary text-lg font-medium">
              Pulled hair?
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "no" as PulledStatus, label: "No" },
                { value: "yes" as PulledStatus, label: "Yes" }
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handlePulledChange(option.value)}
                  className={`py-2 px-4 rounded-lg transition-colors ${
                    pulled === option.value 
                      ? "bg-primary text-white" 
                      : "bg-white/50 hover:bg-white/70"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* Notes */}
          <div className="space-y-2">
            <label htmlFor="notes" className="block text-primary text-lg font-medium">
              Notes (optional)
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={handleNotesChange}
              className="w-full h-24 p-3 bg-white/50 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Enter any additional notes here..."
            ></textarea>
          </div>
          
          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg text-lg"
          >
            Save
          </button>
          
          {/* Cancel Button */}
          <button
            type="button"
            onClick={handleCancel}
            className="w-full bg-white text-primary font-bold py-3 rounded-lg text-lg border border-primary"
          >
            Cancel
          </button>
        </form>
      </div>
    </div>
  );
}