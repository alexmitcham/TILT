import { useState, useEffect } from "react";
import { HomeLogo } from "@/components/HomeLogo";
import { BottomNav } from "@/components/BottomNav";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

// Profile interface for type safety
interface Profile {
  name: string;
  avatar: string;
  bio: string;
  joinDate: string;
  streak: number;
  achievements: string[];
}

// Storage key for profile
const PROFILE_STORAGE_KEY = "tiltProfile";

export default function ProfilePage() {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  // Default profile
  const defaultProfile: Profile = {
    name: "Guest User",
    avatar: "👤",
    bio: "I'm using TILT to track my trichotillomania journey.",
    joinDate: new Date().toISOString().split('T')[0],
    streak: 0,
    achievements: ["Joined TILT"]
  };
  
  const [profile, setProfile] = useState<Profile>(defaultProfile);
  const [editName, setEditName] = useState(profile.name);
  const [editBio, setEditBio] = useState(profile.bio);
  
  // Load profile on initial render
  useEffect(() => {
    try {
      const savedProfile = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (savedProfile) {
        setProfile(JSON.parse(savedProfile));
        console.log("Profile loaded:", JSON.parse(savedProfile));
      } else {
        // If no profile exists, save the default one
        localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(defaultProfile));
        console.log("Default profile saved");
      }
    } catch (error) {
      console.error("Error loading profile:", error);
    }
  }, []);
  
  // Update form fields when profile changes
  useEffect(() => {
    setEditName(profile.name);
    setEditBio(profile.bio);
  }, [profile]);
  
  // Start editing mode
  const handleEdit = () => {
    setIsEditing(true);
  };
  
  // Save profile changes
  const handleSave = () => {
    const updatedProfile = {
      ...profile,
      name: editName,
      bio: editBio,
    };
    
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(updatedProfile));
      setProfile(updatedProfile);
      setIsEditing(false);
      
      toast({
        title: "Profile updated",
        description: "Your profile changes have been saved."
      });
      
      console.log("Profile saved:", updatedProfile);
    } catch (error) {
      console.error("Error saving profile:", error);
      
      toast({
        title: "Error saving profile",
        description: "There was a problem saving your changes.",
        variant: "destructive"
      });
    }
  };
  
  // Cancel editing
  const handleCancel = () => {
    setEditName(profile.name);
    setEditBio(profile.bio);
    setIsEditing(false);
  };
  
  // Calculate days since join date
  const daysSinceJoin = () => {
    const joinDate = new Date(profile.joinDate);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - joinDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  return (
    <div className="container mx-auto max-w-md px-4 pb-20">
      <div className="text-center my-6">
        <HomeLogo className="mb-2" />
        <h1 className="text-2xl font-bold text-primary">My Profile</h1>
      </div>
      
      <div className="bg-secondary rounded-xl p-6 shadow-md mb-6">
        <div className="flex flex-col items-center">
          <div className="text-6xl mb-4">{profile.avatar}</div>
          
          {isEditing ? (
            <div className="w-full space-y-4">
              <div>
                <label htmlFor="name" className="block text-primary font-medium mb-1">
                  Name
                </label>
                <Input
                  id="name" 
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full"
                />
              </div>
              
              <div>
                <label htmlFor="bio" className="block text-primary font-medium mb-1">
                  Bio
                </label>
                <Textarea
                  id="bio"
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full h-24"
                />
              </div>
              
              <div className="flex gap-3">
                <button 
                  onClick={handleSave}
                  className="flex-1 bg-primary text-white py-2 rounded-lg font-medium"
                >
                  Save
                </button>
                <button 
                  onClick={handleCancel}
                  className="flex-1 bg-white border border-primary text-primary py-2 rounded-lg font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="w-full text-center">
              <h2 className="text-xl font-bold mb-2">{profile.name}</h2>
              <p className="text-gray-600 mb-4">{profile.bio}</p>
              
              <button 
                onClick={handleEdit}
                className="bg-primary text-white py-2 px-4 rounded-lg font-medium"
              >
                Edit Profile
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="bg-secondary rounded-xl p-4 shadow-md">
          <h2 className="text-lg font-bold text-primary mb-2">Stats</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center bg-white rounded-lg p-3">
              <p className="text-gray-600 text-sm">Days Using TILT</p>
              <p className="text-2xl font-bold text-primary">{daysSinceJoin()}</p>
            </div>
            <div className="text-center bg-white rounded-lg p-3">
              <p className="text-gray-600 text-sm">Current Streak</p>
              <p className="text-2xl font-bold text-primary">{profile.streak}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-xl p-4 shadow-md">
          <h2 className="text-lg font-bold text-primary mb-2">Achievements</h2>
          <div className="bg-white rounded-lg p-3">
            <ul className="space-y-2">
              {profile.achievements.map((achievement, index) => (
                <li key={index} className="flex items-center">
                  <span className="text-emerald-500 mr-2">✓</span>
                  {achievement}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
}