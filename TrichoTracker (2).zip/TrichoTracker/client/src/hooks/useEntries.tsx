import { useState, useEffect, useCallback } from "react";
import { AppData, Entry } from "@/types";
import { formatDateString } from "@/lib/utils";

const STORAGE_KEY = "tiltAppData";

// Create a function outside the hook to get data from localStorage
const getStoredData = (): Record<string, Entry> => {
  try {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      const parsedData = JSON.parse(savedData) as AppData;
      if (parsedData && parsedData.entries) {
        console.log("Retrieved stored entries:", parsedData.entries);
        return parsedData.entries;
      }
    }
  } catch (error) {
    console.error("Error loading data from localStorage:", error);
  }
  return {};
};

export function useEntries() {
  // Initialize state directly with data from localStorage
  const [entries, setEntries] = useState<Record<string, Entry>>(getStoredData);
  const [isLoaded, setIsLoaded] = useState(true);
  
  console.log("useEntries hook initialized with entries:", entries);

  // Save data to localStorage whenever entries change
  useEffect(() => {
    console.log("Saving entries to localStorage:", entries);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ entries }));
      console.log("Successfully saved to localStorage");
    } catch (error) {
      console.error("Error saving data to localStorage:", error);
    }
  }, [entries]);

  // Add or update an entry
  const saveEntry = useCallback((date: Date, entryData: Omit<Entry, "date" | "timestamp">) => {
    const dateString = formatDateString(date);
    console.log("useEntries.saveEntry called with date:", dateString);
    console.log("Entry data to save:", entryData);
    
    const newEntry = {
      ...entryData,
      date: dateString,
      timestamp: new Date().toISOString()
    };
    
    // Force a direct update to localStorage as well
    const currentData = getStoredData();
    const updatedData = {
      ...currentData,
      [dateString]: newEntry
    };
    
    // Save to localStorage immediately
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ entries: updatedData }));
    console.log("Direct localStorage save", updatedData);
    
    // Update state
    setEntries(updatedData);
  }, []);

  // Get entry for a specific date
  const getEntry = useCallback((date: Date): Entry | undefined => {
    const dateString = formatDateString(date);
    const storedEntries = getStoredData();
    return storedEntries[dateString];
  }, []);

  return {
    entries,
    saveEntry,
    getEntry,
    isLoaded
  };
}
