import { useState } from "react";
import { cn } from "@/lib/utils";

interface MoodSliderProps {
  value: number;
  onChange: (value: number) => void;
  className?: string;
}

export function MoodSlider({ value, onChange, className }: MoodSliderProps) {
  // Create individual buttons for each mood level
  const handleClick = (newValue: number) => {
    onChange(newValue);
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div className="grid grid-cols-10 gap-1">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
          <button
            key={num}
            type="button"
            onClick={() => handleClick(num)}
            className={cn(
              "h-10 rounded-full flex items-center justify-center text-sm transition-all",
              value === num 
                ? "bg-primary text-white scale-110 shadow-md" 
                : "bg-white/50 hover:bg-white/70"
            )}
          >
            {num}
          </button>
        ))}
      </div>
      
      <div className="flex justify-between text-xs text-gray-500 px-1">
        <span>Low mood</span>
        <span>High mood</span>
      </div>
    </div>
  );
}
