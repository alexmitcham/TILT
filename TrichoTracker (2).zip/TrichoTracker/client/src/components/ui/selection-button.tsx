import React from "react";
import { cn } from "@/lib/utils";

interface SelectionButtonProps {
  name: string;
  value: string;
  isChecked: boolean;
  onChange: (value: string) => void;
  children: React.ReactNode;
  className?: string;
}

export function SelectionButton({
  name,
  value,
  isChecked,
  onChange,
  children,
  className,
}: SelectionButtonProps) {
  const id = `${name}-${value}`;

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    onChange(value);
  };

  return (
    <div className={cn("selection-button", className)}>
      <button
        type="button"
        onClick={handleClick}
        className={cn(
          "block w-full py-2 px-4 bg-white/50 rounded-lg text-center cursor-pointer hover:bg-white/70 transition-colors border-2",
          isChecked 
            ? "bg-primary text-white hover:bg-primary/90 border-primary" 
            : "border-transparent"
        )}
      >
        {children}
      </button>
    </div>
  );
}

interface SelectionGroupProps {
  name: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  className?: string;
  gridCols?: string;
}

export function SelectionGroup({
  name,
  value,
  onChange,
  options,
  className,
  gridCols = "grid-cols-3",
}: SelectionGroupProps) {
  return (
    <div className={cn(`grid ${gridCols} gap-2`, className)}>
      {options.map((option) => (
        <SelectionButton
          key={option.value}
          name={name}
          value={option.value}
          isChecked={value === option.value}
          onChange={onChange}
        >
          {option.label}
        </SelectionButton>
      ))}
    </div>
  );
}
