import { cn } from "@/lib/utils";
import { Entry } from "@/types";

interface CalendarDotProps {
  date?: string;
  entry?: Entry;
  onClick?: () => void;
  className?: string;
  dayNumber?: number | null;
  isEmptySlot?: boolean;
}

export function CalendarDot({ 
  date, 
  entry, 
  onClick, 
  className,
  dayNumber,
  isEmptySlot = false
}: CalendarDotProps) {
  // Determine dot color based on entry data
  const getDotColor = () => {
    if (!entry) return ""; // No color for days without entries
    
    if (entry.pulled === "yes") return "bg-red-500";
    if (entry.urge === "mild" || entry.urge === "strong") return "bg-amber-400";
    
    return "bg-emerald-500"; // Green for days with entry but no urge/pull
  };

  if (isEmptySlot) {
    return (
      <div className="w-8 h-8 rounded-full flex items-center justify-center empty-dot"></div>
    );
  }

  const hasEntry = !!entry;
  const dotColor = getDotColor();
  
  // For debugging
  console.log(`Day ${dayNumber}, has entry:`, hasEntry, "color:", dotColor, "entry:", entry);

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-8 h-8 rounded-full flex items-center justify-center text-sm transition-transform hover:scale-110",
        hasEntry ? dotColor : "bg-transparent", // Only apply color for days with entries
        className
      )}
      data-date={date}
    >
      {dayNumber}
    </button>
  );
}

export function CalendarLegend() {
  return (
    <div className="flex justify-center gap-4 text-sm mt-4">
      <div className="flex items-center">
        <div className="w-4 h-4 rounded-full bg-emerald-500 mr-2"></div>
        <span>No Pulling</span>
      </div>
      <div className="flex items-center">
        <div className="w-4 h-4 rounded-full bg-amber-400 mr-2"></div>
        <span>Urge to Pull</span>
      </div>
      <div className="flex items-center">
        <div className="w-4 h-4 rounded-full bg-red-500 mr-2"></div>
        <span>Hair Pulled</span>
      </div>
    </div>
  );
}
