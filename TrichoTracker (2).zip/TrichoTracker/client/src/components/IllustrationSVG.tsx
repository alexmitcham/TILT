import { cn } from "@/lib/utils";
import ladyImage from "@/assets/Lady.png";

interface IllustrationSVGProps {
  className?: string;
}

export function IllustrationSVG({ className }: IllustrationSVGProps) {
  return (
    <div className={cn("w-full h-full flex justify-center", className)}>
      <img 
        src={ladyImage} 
        alt="Woman with trich" 
        className="max-w-full max-h-[300px]" 
      />
    </div>
  );
}
