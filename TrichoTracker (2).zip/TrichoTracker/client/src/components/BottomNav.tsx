import { useLocation } from "wouter";
import { Calendar, BookOpen, Users, User, BarChart2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location, navigate] = useLocation();

  const navItems = [
    { icon: Calendar, label: "Tracker", path: "/tracker" },
    { icon: BarChart2, label: "Stats", path: "/stats" },
    { icon: Users, label: "Community", path: "/community" },
    { icon: BookOpen, label: "Resources", path: "/resources" },
    { icon: User, label: "Profile", path: "/profile" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-secondary flex items-center justify-around py-2 shadow-lg">
      {navItems.map((item) => {
        const isActive = location === item.path;
        
        return (
          <button
            key={item.path}
            className={cn(
              "flex flex-col items-center p-2 rounded-lg w-[19%]",
              isActive 
                ? "text-primary font-medium" 
                : "text-foreground/60 hover:text-foreground/80"
            )}
            onClick={() => navigate(item.path)}
          >
            <item.icon className={cn(
              "h-6 w-6 mb-1",
              isActive ? "text-primary" : "text-foreground/60"
            )} />
            <span className="text-xs">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}