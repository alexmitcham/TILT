import { cn } from "@/lib/utils";
import logoImage from "@/assets/logo3.png";

interface HomeLogoProps {
  className?: string;
}

export function HomeLogo({ className }: HomeLogoProps) {
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <img 
        src={logoImage} 
        alt="TILT Logo" 
        className="mb-2 w-auto"
        style={{ height: "140px" }}
      />
    </div>
  );
}
