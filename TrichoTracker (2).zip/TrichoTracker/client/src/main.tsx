import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Apply global styles to match the mockup
document.documentElement.style.setProperty("--background", "0 27% 95%");  // #FCEEE3
document.documentElement.style.setProperty("--secondary", "32 54% 90%");  // #F4E6D8
document.documentElement.style.setProperty("--foreground", "29 15% 25%"); // #4A3F35
document.documentElement.style.setProperty("--green", "120 30% 74%");     // #A6D5A6 
document.documentElement.style.setProperty("--yellow", "46 86% 82%");     // #F9E4A9
document.documentElement.style.setProperty("--red", "0 65% 70%");         // #E57F7F

createRoot(document.getElementById("root")!).render(<App />);
