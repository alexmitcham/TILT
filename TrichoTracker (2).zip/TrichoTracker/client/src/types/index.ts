export type EntryStatus = "none" | "mild" | "strong";
export type PulledStatus = "yes" | "no";

export interface Entry {
  date: string;
  mood: number;
  urge: EntryStatus;
  pulled: PulledStatus;
  notes?: string;
  timestamp: string;
}

export interface AppData {
  entries: Record<string, Entry>;
}

export type DayInfo = {
  date: Date;
  dayNumber: number;
  dateString: string;
};
